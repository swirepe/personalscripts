/* Copyright 1990-2011, Jsoftware Inc.  All rights reserved. */
/* License in license.txt.                                   */
/*                                                                         */
/* Verbs: Extended Precision Floating Point                                */

#include "j.h"
#include "ve.h"


DXF2(jtdxplus){DX z=zeroDX;
 R z;
}


APFX(plusDX, DX,DX,DX, dxplus )

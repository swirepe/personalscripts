/* Copyright 1990-2011, Jsoftware Inc.  All rights reserved. */
/* License in license.txt.                                   */
/*                                                                         */
/* Verbs: "Multiplication" on Sparse Arrays                                */

#include "j.h"
#include "ve.h"


B jtspmult(J jt,A*z,A a,A w,C id,I af,I acr,I wf,I wcr){
 R 0;
}    /* scalar dyadic fns with one or both arguments sparse */

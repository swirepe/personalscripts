Click the New Tiddler link to the left, and Name the tiddler ‘StyleSheetSyntaxHighlighter’ Navigate to your unzipped archive and cut and paste the contents of ‘SyntaxHighlighter.css’ into your new tiddler.

Navigate to the Shadow tiddler ‘StyleSheet’ and add [[StyleSheetSyntaxHighlighter]]



Add another ‘New Tiddler’ named ‘SyntaxHighlighterPlugin’ and paste the contents of ‘shPlugin.js’ into this tiddler, then tag the tiddler with ‘systemConfig’

Finish everything up by copying ‘clipboard.swf’ to the directory of your TiddlyWiki…

http://fsk141.com/tiddlywiki-syntax-highlighter/
